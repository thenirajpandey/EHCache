package com.openmatics.omob.clientlogin;

import static org.junit.Assert.*;

import org.junit.Test;

import com.openmatics.omob.clientlogin.management.services.UserManagementImpl;

public class Test1 {

//	@Test
	public void testCreateUser() {
		fail("Not yet implemented");
	}

//	@Test
	public void testGetAllUsers() {
		fail("Not yet implemented");
	}

//	@Test
	public void testUpdateUser() {
		fail("Not yet implemented");
	}

// @Test
	public void testDeleteUser() {
		fail("Not yet implemented");
	}

//	@Test
	public void testGetUserByName() {
		UserManagementImpl externalUserAccount = new UserManagementImpl();
		/*when(service.getExternalUserByExternalId(externalUserAccount.getExternalId())).thenReturn(externalUserAccount)
				.thenThrow(new AccountDoesNotExistException());
		Assert.assertEquals(appController.getUserById(externalUserAccount.getExternalId()),
				new ResponseEntity<ExternalUserAccount>(externalUserAccount, HttpStatus.OK));*/

		fail("Not yet implemented");
	}

}
